################################################################################
#(_)                                                                           #
# |_________________________________________                                   #
# |*  *  *  *  * |##########################|                                  #
# | *  *  *  *  *|==========================|                                  #
# |*  *  *  *  * |##########################|                                  #
# | *  *  *  *  *|==========================|                                  #
# |*  *  *  *  * |##########################|      If your going to copy       #
# | *  *  *  *  *|==========================|         this addon just          #
# |*  *  *  *  * |##########################|         give credit!!!!          #
# |--------------|==========================|                                  #
# |#########################################|                                  #
# |=========================================|                                  #
# |#########################################|                                  #
# |=========================================|                                  #
# |#########################################|                                  #
# |-----------------------------------------|                                  #
# |                                                                            #
# |    Heavily Modified By FTG                                                 #
# |    Copyright (C) 2012 Mikeys Karaoke                                       #
# |                                                                            #
# |    This program is free software: you can redistribute it and/or modify    #
# |    it under the terms of the GNU General Public License as published by    #
# |    the Free Software Foundation, either version 3 of the License, or       #
# |    (at your option) any later version.                                     #
# |                                                                            #
# |    This program is distributed in the hope that it will be useful,         #
# |    but WITHOUT ANY WARRANTY; without even the implied warranty of          #
# |    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
# |    GNU General Public License for more details.                            #
# |                                                                            #
################################################################################

import urllib,urllib2,re,sys,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,xbmcvfs,string
try:
    import json
except:
    import simplejson as json
import datetime
import time
from resources.modules import net
from resources.modules import yt
from sqlite3 import dbapi2 as database
import sqlite3

PLUGIN         = 'plugin.video.ftgkaraoke'
net            = net.Net()
youtubeaddon   = xbmcaddon.Addon(id='plugin.video.youtube')
local          = xbmcaddon.Addon(id=PLUGIN)
ADDON          = local
profile       = xbmc.translatePath(ADDON.getAddonInfo('profile').decode('utf-8'))
db_dir = os.path.join(xbmc.translatePath("special://database"), 'FTGkaraoke.db')
home           = ADDON.getAddonInfo('path')
newfont        = ADDON.getSetting('newfont').lower()
art            = "%s/KaraokeArt/"%local.getAddonInfo("path")

def addon():
    return ADDON
def refresh():
    return xbmc.executebuiltin('Container.Refresh')
def idle():
    return xbmc.executebuiltin('Dialog.Close(busydialog)')
addonInfo = xbmcaddon.Addon().getAddonInfo
def selectDialog(list, heading=addonInfo('name')):
    dialog = xbmcgui.Dialog()
    return dialog.select(heading, list)

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def CATEGORIES():
        addItem('[COLOR '+newfont+']Some Links May Take 2 Clicks If They Fail![/COLOR]','','',art+'Main/youtube.png',art+'Main/karaoke.jpg','')
        addItem('[COLOR '+newfont+']---------------------------------[/COLOR]','','',art+'Main/youtube.png',art+'Main/karaoke.jpg','')
        addDir('[COLOR '+newfont+']'+'Search[/COLOR]-[COLOR '+newfont+']'+'Y[/COLOR]outube Karaoke','url',3,art+'Main/Search.png',art+'Main/karaoke.jpg',1)
        addDir('[COLOR '+newfont+']'+'Most[/COLOR] Popular','http://www.sunflykaraoke.com/tracks?dir=asc&limit=200&order=popular',7,art+'AtoZ/P.png',art+'Main/karaoke.jpg',1)
        addDir('[COLOR '+newfont+']'+'L[/COLOR]atest','http://www.sunflykaraoke.com/tracks?dir=asc&limit=200&order=latestalbums',7,art+'AtoZ/L.png',art+'Main/karaoke.jpg',1)
        addDir('[COLOR '+newfont+']'+'Browse[/COLOR] Artist','http://www.lyricsmania.com/lyrics/%s.html',1,art+'Main/Artist.png',art+'Main/karaoke.jpg',4)
        addDir('[COLOR '+newfont+']'+'Browse[/COLOR] Tracks','http://www.sunflykaraoke.com/tracks/search/byletter/letter/%s/',1,art+'Main/Title.png',art+'Main/karaoke.jpg',7)
        addDir('[COLOR '+newfont+']'+'G[/COLOR]enre','http://www.sunflykaraoke.com/',8,art+'Main/Genre.png',art+'Main/karaoke.jpg',1)
        addItem('[COLOR '+newfont+']---------------------------------[/COLOR]','','',art+'Main/youtube.png',art+'Main/karaoke.jpg','')
        addDir('[COLOR '+newfont+']'+'F[/COLOR]avorites','http://www.sunflykaraoke.com/',2,art+'Main/favorites.png',art+'Main/karaoke.jpg',1)
        addItem('[COLOR '+newfont+']---------------------------------[/COLOR]','','',art+'Main/youtube.png',art+'Main/karaoke.jpg','')
        addDir('[COLOR '+newfont+']'+'Change[/COLOR] Font Color','url',20,art+'Main/color.png',art+'Main/karaoke.jpg',1)
        setView('movies', 'MAIN')

def AtoZ(url,number,fanart):
    if '%s' in url:
        addDir('[COLOR '+newfont+']0-9[/COLOR]',url%'0-9',number,"%s/KaraokeArt/AtoZ/%s.png"%(local.getAddonInfo("path"),'0-9'),fanart,1)
        for i in string.ascii_uppercase:
            addDir('[COLOR '+newfont+']%s[/COLOR]' % i,url%i,number,"%s/KaraokeArt/AtoZ/%s.png"%(local.getAddonInfo("path"),i),fanart,1)
    else:
        for i in string.ascii_uppercase:
            addDir('[COLOR '+newfont+']%s[/COLOR]' % i,url,number,"%s/KaraokeArt/AtoZ/%s.png"%(local.getAddonInfo("path"),i),fanart,1)
    setView('movies', 'A-Z')
        
def GENRE(url):
        link=net.http_GET('http://www.sunflykaraoke.com/genre').content.encode('ascii','ignore')
        match=re.compile('class="thumb_img">.+?<img src="(.+?)".+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(link)
        for iconimage,url , name in match:
            addDir('[COLOR '+newfont+']%s[/COLOR]' % name,url+'?dir=asc&order=latestalbums',10,iconimage,art+'Main/Fanart_G.jpg',1) 
        
        setView('movies', 'GENRE')
        
def Next_Page(link):
    link = link.split('class="paging-bar-pages">')[1]
    link=link.split('<a href=')
    for l in link:
        match=re.compile('"(.+?)#.+?" class="arrow">&gt;</a>').findall(l)        
        if match:
            return match
    return None 
    

def SEARCH(url):
        PAGE=1
        keyboard = xbmc.Keyboard('', 'Search For Artist and Song Title')
        keyboard.doModal()
        if keyboard.isConfirmed() and len(keyboard.getText())>0:
           TXT='https://www.youtube.com/results?search_query=%s+intitle:karaoke,+Video&hl=en-GB&page='  % (keyboard.getText().replace(' ','+'))
           html=OPEN_URL(TXT+str(PAGE))
        else: return
        
        link=html.split('yt-lockup-title')
        
        for p in link:
            #print p
            try:
                url=p.split('watch?v=')[1]
                name= p.split('title="')[1]
                name=name.split('"')[0]  
                name = str(name).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","").replace("[","").replace("]","").replace("-"," ")
                iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % url.split('"')[0]
                if not 'video_id' in name:
                    if not '_title_' in name:
                        addLink('[COLOR '+newfont+']%s[/COLOR]' % name,url.split('"')[0] ,iconimage,'')
            except:pass
   
        addDir('[COLOR royalblue][B]Next Page >>[/B][/COLOR]',TXT,11,art+'nextpage.png','',PAGE)
        setView('movies', 'VIDEO')
        

def ARTIST_INDEX(url, iconimage):
        link=net.http_GET(url).content.encode('ascii','ignore')
        match = re.compile('<a href="(.+?)" title="(.+?)"').findall(link)
        for url, name in match:
            url = 'http://www.lyricsmania.com'+url   
            name = str(name).replace("lyrics","")
            addDir('[COLOR '+newfont+']%s[/COLOR]' % name,url,5,iconimage,art+'Main/Fanart_A.jpg',1)
        setView('movies', 'DEFAULT')


def ARTIST_SONG_INDEX(url,name):
        link=net.http_GET(url).content
        match = re.compile('http://www.musictory.com/(.+?)"').findall(link)
        url1 = 'http://www.musictory.com/'+match[0]+'/Songs'
        link1=net.http_GET(url1).content
        url = re.compile('<h1 itemprop="name">(.+?) Songs<').findall(link1)[0]
        match1 = re.compile('<span itemprop="name">(.+?)</span>').findall(link1)
        fanart = art+'Main/Fanart_A.jpg'
        for name in match1:
            name=name.encode('ascii','ignore')
            name = str(name).replace("&Agrave;","A").replace('&eacute;','e').replace('&ecirc;','e').replace('&egrave;','e').replace("&agrave;","A")
            addDir('[COLOR '+newfont+']%s[/COLOR]' % name,'url',6,iconimage,fanart,1)
        setView('tvshow', 'DEFAULT')
    
def TRACK_INDEX(url, iconimage):
        link=OPEN_URL(url.replace(' ','%20'))
        match = re.compile('<li><span>.+?href=.+?title="(.+?)">.+?> - <.+?>(.+?)</a>').findall(link)
        uniques = []        
        for name, url, in match:

                name = str(name).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","")  
                url = str(url).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","") 
                name = name+ '   ('+ url+')'
                if not '</a>' in name:
                    if name not in uniques:
                        uniques.append(name)      
                        addDir('[COLOR '+newfont+']%s[/COLOR]' % name,url,9,iconimage,art+'Main/Fanart_T.jpg',1)
        setView('movies', 'DEFAULT')
                
def GENRE_INDEX(name,url, iconimage):
        link=OPEN_URL(url.replace(' ','%20'))
        match = re.compile('<div class="track_det" style="width:80%">.+?<p><a href=".+?s">(.+?)<.+?<p class="trkname">.+?href=".+?">(.+?)<',re.DOTALL).findall(link)
        uniques=[]
        for name, url, in match:
            name = str(name).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","")  
            url = str(url).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","") 
            name = name+ '   ('+ url+')'
            if not '</a>' in name:
                if name not in uniques:
                    uniques.append(name)      
    
                    addDir('[COLOR '+newfont+']%s[/COLOR]' % name,url,9,iconimage,art+'Main/Fanart_G.jpg',1)
        setView('movies', 'DEFAULT')

def YOUTUBE_SONG_INDEX(name, url, iconimage, fanart):
        PAGE=1
        url = str(url).replace(' ','+').replace('_','+')  
        name = str(name).replace(' ','+') 
        url = 'https://www.youtube.com/results?search_query=%s+%s+Karaoke+Version&hl=en-GB&page=' % (name, url) 
        html=OPEN_URL(url)
        link=html.split('yt-lockup-title')
        for p in link:
            try:
                url=p.split('watch?v=')[1]
                name= p.split('title="')[1]
                name=name.split('"')[0]  
                name = str(name).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","").replace("[","").replace("]","").replace("-"," ")
                iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % url.split('"')[0]
                if not 'video_id' in name:
                    if not '_title_' in name:
                        addLink('[COLOR '+newfont+']%s[/COLOR]' % name,url.split('"')[0] ,iconimage,'')
            except:pass
   
        addDir('[COLOR royalblue][B]Next Page >>[/B][/COLOR]',url,11,art+'nextpage.png','',PAGE)
        setView('movies', 'DEFAULT')

def TITLE_ORDERS_YOUTUBE(name, url,fanart):
        PAGE=1
        name = str(name).replace('   (','+') .replace(' ','+') .replace(')','')
        url = 'https://www.youtube.com/results?search_query=%s+karaoke&hl=en-GB&page=' % (name) 
        #print url
        html=OPEN_URL(url)
        link=html.split('yt-lockup-title')
        for p in link:
            try:
                url=p.split('watch?v=')[1]
                name= p.split('title="')[1]
                name=name.split('"')[0]  
                name = str(name).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","").replace("[","").replace("]","").replace("-"," ")
                iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % url.split('"')[0]
                if not 'video_id' in name:
                    if not '_title_' in name:
                        addLink('[COLOR '+newfont+']%s[/COLOR]' % name,url.split('"')[0] ,iconimage,'')
            except:pass
   
        addDir('[COLOR royalblue][B]Next Page >>[/B][/COLOR]',url,11,art+'nextpage.png','',PAGE)
        setView('movies', 'DEFAULT')

def Fcolor():
    setSetting = xbmcaddon.Addon().setSetting
    idle()
    items = [
            ('[B][COLOR aliceblue]aliceblue [/COLOR][/B]', 'aliceblue' ),
('[B][COLOR antiquewhite]antiquewhite [/COLOR][/B]', 'antiquewhite' ),
('[B][COLOR aqua]aqua [/COLOR][/B]', 'aqua' ),
('[B][COLOR aquamarine]aquamarine [/COLOR][/B]', 'aquamarine' ),
('[B][COLOR azure]azure [/COLOR][/B]', 'azure' ),
('[B][COLOR beige]beige [/COLOR][/B]', 'beige' ),
('[B][COLOR bisque]bisque [/COLOR][/B]', 'bisque' ),
('[B][COLOR blanchedalmond]blanchedalmond [/COLOR][/B]', 'blanchedalmond' ),
('[B][COLOR blue]blue [/COLOR][/B]', 'blue' ),
('[B][COLOR blueviolet]blueviolet [/COLOR][/B]', 'blueviolet' ),
('[B][COLOR brown]brown [/COLOR][/B]', 'brown' ),
('[B][COLOR burlywood]burlywood [/COLOR][/B]', 'burlywood' ),
('[B][COLOR cadetblue]cadetblue [/COLOR][/B]', 'cadetblue' ),
('[B][COLOR chartreuse]chartreuse [/COLOR][/B]', 'chartreuse' ),
('[B][COLOR chocolate]chocolate [/COLOR][/B]', 'chocolate' ),
('[B][COLOR coral]coral [/COLOR][/B]', 'coral' ),
('[B][COLOR cornflowerblue]cornflowerblue [/COLOR][/B]', 'cornflowerblue' ),
('[B][COLOR cornsilk]cornsilk [/COLOR][/B]', 'cornsilk' ),
('[B][COLOR crimson]crimson [/COLOR][/B]', 'crimson' ),
('[B][COLOR cyan]cyan [/COLOR][/B]', 'cyan' ),
('[B][COLOR darkblue]darkblue [/COLOR][/B]', 'darkblue' ),
('[B][COLOR darkcyan]darkcyan [/COLOR][/B]', 'darkcyan' ),
('[B][COLOR darkgoldenrod]darkgoldenrod [/COLOR][/B]', 'darkgoldenrod' ),
('[B][COLOR darkgray]darkgray [/COLOR][/B]', 'darkgray' ),
('[B][COLOR darkgreen]darkgreen [/COLOR][/B]', 'darkgreen' ),
('[B][COLOR darkgrey]darkgrey [/COLOR][/B]', 'darkgrey' ),
('[B][COLOR darkkhaki]darkkhaki [/COLOR][/B]', 'darkkhaki' ),
('[B][COLOR darkmagenta]darkmagenta [/COLOR][/B]', 'darkmagenta' ),
('[B][COLOR darkolivegreen]darkolivegreen [/COLOR][/B]', 'darkolivegreen' ),
('[B][COLOR darkorange]darkorange [/COLOR][/B]', 'darkorange' ),
('[B][COLOR darkorchid]darkorchid [/COLOR][/B]', 'darkorchid' ),
('[B][COLOR darkred]darkred [/COLOR][/B]', 'darkred' ),
('[B][COLOR darksalmon]darksalmon [/COLOR][/B]', 'darksalmon' ),
('[B][COLOR darkseagreen]darkseagreen [/COLOR][/B]', 'darkseagreen' ),
('[B][COLOR darkslateblue]darkslateblue [/COLOR][/B]', 'darkslateblue' ),
('[B][COLOR darkslategray]darkslategray [/COLOR][/B]', 'darkslategray' ),
('[B][COLOR darkturquoise]darkturquoise [/COLOR][/B]', 'darkturquoise' ),
('[B][COLOR darkviolet]darkviolet [/COLOR][/B]', 'darkviolet' ),
('[B][COLOR deeppink]deeppink [/COLOR][/B]', 'deeppink' ),
('[B][COLOR deepskyblue]deepskyblue [/COLOR][/B]', 'deepskyblue' ),
('[B][COLOR dimgray]dimgray [/COLOR][/B]', 'dimgray' ),
('[B][COLOR dimgrey]dimgrey [/COLOR][/B]', 'dimgrey' ),
('[B][COLOR dodgerblue]dodgerblue [/COLOR][/B]', 'dodgerblue' ),
('[B][COLOR firebrick]firebrick [/COLOR][/B]', 'firebrick' ),
('[B][COLOR floralwhite]floralwhite [/COLOR][/B]', 'floralwhite' ),
('[B][COLOR forestgreen]forestgreen [/COLOR][/B]', 'forestgreen' ),
('[B][COLOR fuchsia]fuchsia [/COLOR][/B]', 'fuchsia' ),
('[B][COLOR gainsboro]gainsboro [/COLOR][/B]', 'gainsboro' ),
('[B][COLOR ghostwhite]ghostwhite [/COLOR][/B]', 'ghostwhite' ),
('[B][COLOR gold]gold [/COLOR][/B]', '' ),
('[B][COLOR goldenrod]goldenrod [/COLOR][/B]', 'goldenrod' ),
('[B][COLOR gray]gray [/COLOR][/B]', 'gray' ),
('[B][COLOR green]green [/COLOR][/B]', 'green' ),
('[B][COLOR greenyellow]greenyellow [/COLOR][/B]', 'greenyellow' ),
('[B][COLOR grey]grey [/COLOR][/B]', 'grey' ),
('[B][COLOR honeydew]honeydew [/COLOR][/B]', 'honeydew' ),
('[B][COLOR hotpink]hotpink [/COLOR][/B]', 'hotpink' ),
('[B][COLOR indianred]indianred [/COLOR][/B]', 'indianred' ),
('[B][COLOR indigo]indigo [/COLOR][/B]', 'indigo' ),
('[B][COLOR ivory]ivory [/COLOR][/B]', 'ivory' ),
('[B][COLOR khaki]khaki [/COLOR][/B]', 'khaki' ),
('[B][COLOR lavender]lavender [/COLOR][/B]', 'lavender' ),
('[B][COLOR lavenderblush]lavenderblush [/COLOR][/B]', '' ),
('[B][COLOR lawngreen]lawngreen [/COLOR][/B]', 'lawngreen' ),
('[B][COLOR lemonchiffon]lemonchiffon [/COLOR][/B]', 'lemonchiffon' ),
('[B][COLOR lightblue]lightblue [/COLOR][/B]', 'lightblue' ),
('[B][COLOR lightcoral]lightcoral [/COLOR][/B]', 'lightcoral' ),
('[B][COLOR lightcyan]lightcyan [/COLOR][/B]', 'lightcyan' ),
('[B][COLOR lightgoldenrodyellow]lightgoldenrodyellow [/COLOR][/B]', 'lightgoldenrodyellow' ),
('[B][COLOR lightgray]lightgray [/COLOR][/B]', 'lightgray' ),
('[B][COLOR lightgreen]lightgreen [/COLOR][/B]', '' ),
('[B][COLOR lightgrey]lightgrey [/COLOR][/B]', '' ),
('[B][COLOR lightpink]lightpink [/COLOR][/B]', '' ),
('[B][COLOR lightsalmon]lightsalmon [/COLOR][/B]', '' ),
('[B][COLOR lightseagreen]lightseagreen [/COLOR][/B]', 'lightseagreen' ),
('[B][COLOR lightskyblue]lightskyblue [/COLOR][/B]', 'lightskyblue' ),
('[B][COLOR lightslategray]lightslategray [/COLOR][/B]', 'lightslategray' ),
('[B][COLOR lightslategrey]lightslategrey [/COLOR][/B]', 'lightslategrey' ),
('[B][COLOR lightsteelblue]lightsteelblue [/COLOR][/B]', 'lightsteelblue' ),
('[B][COLOR lightyellow]lightyellow [/COLOR][/B]', 'lightyellow' ),
('[B][COLOR lime]lime [/COLOR][/B]', 'lime' ),
('[B][COLOR limegreen]limegreen [/COLOR][/B]', 'limegreen' ),
('[B][COLOR linen]linen [/COLOR][/B]', 'linen' ),
('[B][COLOR magenta]magenta [/COLOR][/B]', 'magenta' ),
('[B][COLOR maroon]maroon [/COLOR][/B]', 'maroon' ),
('[B][COLOR mediumaquamarine]mediumaquamarine [/COLOR][/B]', 'mediumaquamarine' ),
('[B][COLOR mediumblue]mediumblue [/COLOR][/B]', 'mediumblue' ),
('[B][COLOR mediumorchid]mediumorchid [/COLOR][/B]', 'mediumorchid' ),
('[B][COLOR mediumpurple]mediumpurple [/COLOR][/B]', 'mediumpurple' ),
('[B][COLOR mediumseagreen]mediumseagreen [/COLOR][/B]', 'mediumseagreen' ),
('[B][COLOR mediumslateblue]mediumslateblue [/COLOR][/B]', 'mediumslateblue' ),
('[B][COLOR mediumspringgreen]mediumspringgreen [/COLOR][/B]', '' ),
('[B][COLOR mediumturquoise]mediumturquoise [/COLOR][/B]', 'mediumspringgreen' ),
('[B][COLOR mediumvioletred]mediumvioletred [/COLOR][/B]', 'mediumvioletred' ),
('[B][COLOR midnightblue]midnightblue [/COLOR][/B]', '' ),
('[B][COLOR mintcream]mintcream [/COLOR][/B]', 'mintcream' ),
('[B][COLOR mistyrose]mistyrose [/COLOR][/B]', 'mistyrose' ),
('[B][COLOR moccasin]moccasin [/COLOR][/B]', 'moccasin' ),
('[B][COLOR navajowhite]navajowhite [/COLOR][/B]', 'navajowhite' ),
('[B][COLOR navy]navy [/COLOR][/B]', 'navy' ),
('[B][COLOR none]none [/COLOR][/B]', 'none' ),
('[B][COLOR oldlace]oldlace [/COLOR][/B]', 'oldlace' ),
('[B][COLOR olive]olive [/COLOR][/B]', 'olive' ),
('[B][COLOR olivedrab]olivedrab [/COLOR][/B]', 'olivedrab' ),
('[B][COLOR orange]orange [/COLOR][/B]', 'orange' ),
('[B][COLOR orangered]orangered [/COLOR][/B]', 'orangered' ),
('[B][COLOR orchid]orchid [/COLOR][/B]', 'orchid' ),
('[B][COLOR palegoldenrod]palegoldenrod [/COLOR][/B]', 'palegoldenrod' ),
('[B][COLOR palegreen]palegreen [/COLOR][/B]', 'palegreen' ),
('[B][COLOR paleturquoise]paleturquoise [/COLOR][/B]', 'paleturquoise' ),
('[B][COLOR palevioletred]palevioletred [/COLOR][/B]', 'palevioletred' ),
('[B][COLOR papayawhip]papayawhip [/COLOR][/B]', 'papayawhip' ),
('[B][COLOR peachpuff]peachpuff [/COLOR][/B]', 'peachpuff' ),
('[B][COLOR peru]peru [/COLOR][/B]', 'peru' ),
('[B][COLOR pink]pink [/COLOR][/B]', 'pink' ),
('[B][COLOR plum]plum [/COLOR][/B]', 'plum' ),
('[B][COLOR powderblue]powderblue [/COLOR][/B]', 'powderblue' ),
('[B][COLOR purple]purple [/COLOR][/B]', 'purple' ),
('[B][COLOR red]red [/COLOR][/B]', 'red' ),
('[B][COLOR rosybrown]rosybrown [/COLOR][/B]', 'rosybrown' ),
('[B][COLOR royalblue]royalblue [/COLOR][/B]', 'royalblue' ),
('[B][COLOR saddlebrown]saddlebrown [/COLOR][/B]', 'saddlebrown' ),
('[B][COLOR salmon]salmon [/COLOR][/B]', 'salmon' ),
('[B][COLOR sandybrown]sandybrown [/COLOR][/B]', 'sandybrown' ),
('[B][COLOR seagreen]seagreen [/COLOR][/B]', 'seagreen' ),
('[B][COLOR seashell]seashell [/COLOR][/B]', 'seashell' ),
('[B][COLOR sienna]sienna [/COLOR][/B]', 'sienna' ),
('[B][COLOR silver]silver [/COLOR][/B]', 'silver' ),
('[B][COLOR skyblue]skyblue [/COLOR][/B]', 'skyblue' ),
('[B][COLOR slateblue]slateblue [/COLOR][/B]', 'slateblue' ),
('[B][COLOR slategray]slategray [/COLOR][/B]', 'slategray' ),
('[B][COLOR slategrey]slategrey [/COLOR][/B]', 'slategrey' ),
('[B][COLOR snow]snow [/COLOR][/B]', 'snow' ),
('[B][COLOR springgreen]springgreen [/COLOR][/B]', 'springgreen' ),
('[B][COLOR steelblue]steelblue [/COLOR][/B]', 'steelblue' ),
('[B][COLOR tan]tan [/COLOR][/B]', 'tan' ),
('[B][COLOR teal]teal [/COLOR][/B]', 'teal' ),
('[B][COLOR thistle]thistle [/COLOR][/B]', 'thistle' ),
('[B][COLOR tomato]tomato [/COLOR][/B]', 'tomato' ),
('[B][COLOR transparent]transparent [/COLOR][/B]', 'transparent' ),
('[B][COLOR turquoise]turquoise [/COLOR][/B]', 'turquoise' ),
('[B][COLOR violet]violet [/COLOR][/B]', 'violet' ),
('[B][COLOR wheat]wheat [/COLOR][/B]', 'wheat' ),
('[B][COLOR white]white [/COLOR][/B]', 'white' ),
('[B][COLOR whitesmoke]whitesmoke [/COLOR][/B]', 'whitesmoke' ),
('[B][COLOR yellow]yellow [/COLOR][/B]', 'yellow' ),
('[B][COLOR yellowgreen]yellowgreen [/COLOR][/B]', 'yellowgreen' )
        ]
    select = selectDialog([i[0] for i in items], 'Select Font Color')
    if select == -1: return
    items =  items[select][1]
    setSetting('newfont','%s' % items)
    refresh()
    return
            
def nextpage(url,number):
        URL=url
        PAGE=int(number)+1
        html=OPEN_URL(url+str(PAGE))
        link=html.split('yt-lockup-title')
        for p in link:
            try:
                url=p.split('watch?v=')[1]
                url=url.split('"')[0]
                if '&amp' in url:
                    url=url.split('&amp')[0]
                name= p.split('title="')[1]
                name=name.split('"')[0]  
                name = str(name).replace("&#39;","'") .replace("&amp;","and") .replace("&#252;","u") .replace("&quot;","").replace("[","").replace("]","").replace("-"," ")
                iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % url
                if not 'video_id' in name:
                    if not '_title_' in name:
                        if not 'video search' in name.lower():
                            addLink('[COLOR '+newfont+']%s[/COLOR]' % name,url ,iconimage,'')
            except:pass
   
        addDir('[COLOR royalblue][B]Next Page >>[/B][/COLOR]',URL,11,art+'nextpage.png','',PAGE)
        setView('movies', 'VIDEO')
            
				
					   
                           
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}#F&T*G
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

        
def addDir(name,url,mode,iconimage,fanart,number):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&number="+str(number)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty( "Fanart_Image", fanart )
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        if mode==20:#F*T^G
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz, isFolder=True)
        if not mode==1 and mode==20 and mode==19:
            xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)

def addItem(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty( "Fanart_Image", fanart )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

	
def addLink(name,url,iconimage, fanart,showcontext=True):
    youtube = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % url
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true")
    liz.setProperty("Fanart_Image", fanart )
    menu = []
    if showcontext:
        menu.append(('[COLOR green]Add[/COLOR] to Karaoke Favorites','XBMC.RunPlugin(%s?mode=2&iconimage=%s&url=%s&name=%s&switch=%s)' %(sys.argv[0],iconimage,url,name,'add')))
    liz.addContextMenuItems(items=menu, replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=youtube,listitem=liz,isFolder=False)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)

def addLinkF(name,url,iconimage, fanart,showcontext=True):
    youtube = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % iconimage
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty("IsPlayable","true")
    liz.setProperty("Fanart_Image", fanart )
    menu = []
    if showcontext:
        menu.append(('[COLOR red]Remove[/COLOR] from Karaoke Favourites','XBMC.RunPlugin(%s?mode=2&iconimage=%s&url=%s&name=%s&switch=%s)' %(sys.argv[0],iconimage,url,name,'delete')))
    liz.addContextMenuItems(items=menu, replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=youtube,listitem=liz,isFolder=False)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
	
db = sqlite3.connect(db_dir)
db.execute('CREATE TABLE IF NOT EXISTS favourites (name,url,iconimage, fanart)')
db.commit()
db.close()

def FAVOURITES(switch,name,iconimage,url):
    IMAGE = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')
    db = sqlite3.connect(db_dir);cur = db.cursor()
    if switch == 'add':
        sql = "INSERT OR REPLACE INTO favourites (name,iconimage,url) VALUES(?,?,?)"
        cur.execute(sql, (name,iconimage.replace(' ','%20'),url.replace(' ','%20')))
        db.commit(); db.close()
        xbmc.executebuiltin('XBMC.Notification('+name+',Added to Favorites,2000,'+IMAGE+')')
    if switch == 'delete':
        cur.execute("DELETE FROM favourites WHERE name=?", (name,))
        db.commit(); db.close()
        xbmc.executebuiltin('XBMC.Notification('+name.replace('  ',' ')+',Deleted from Favorites,2000,'+IMAGE+')')
        xbmc.executebuiltin("XBMC.Container.Refresh")
    if switch == 'display':
        cur.execute("SELECT * FROM favourites")
        cached = cur.fetchall()
        if cached:
            for name,iconimage,url,fanart in cached:
                addLinkF(name,url,iconimage,fanart)

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        switch=urllib.unquote_plus(params["switch"])
except:
        switch='display'
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        number=int(params["number"])
except:
        pass
try:        
        split=int(params["split"])
except:
        pass
                
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
print "FanartImage: "+str(fanart)
try:print "number: "+str(number)
except:pass

def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
    AtoZ(url,number,fanart)

elif mode==2:
    FAVOURITES(switch,name,iconimage,url)
        
elif mode==3:
        print ""+url
        SEARCH(url)
        
elif mode==4:
        ARTIST_INDEX(url, iconimage) 
        
elif mode==5:
        ARTIST_SONG_INDEX(url,name)
        
elif mode==6:
        YOUTUBE_SONG_INDEX(name, url, iconimage, fanart)
                                                             
elif mode==7:
        TRACK_INDEX(url, iconimage)
        
elif mode==8:
        GENRE(url)   
        
elif mode==9:
        TITLE_ORDERS_YOUTUBE(name, url, fanart)   
        
elif mode==10:
        GENRE_INDEX(name,url, iconimage)
                      
elif mode==11:
        nextpage(url,number)  

elif mode==20:
    Fcolor()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
